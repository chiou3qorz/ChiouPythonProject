def sayHello():
    print("Hello")