# ChiouPythonProject
an example
http://dokelung-blog.logdown.com/posts/238050-collation-and-publishing-of-the-project-from-github-to-pypi

python setup.py register sdist upload -r https://www.python.org/pypi


ChiouPythonProject
e:
cd E:\GitData
git clone https://github.com/chiou3qorz/ChiouPythonProject.gitt
